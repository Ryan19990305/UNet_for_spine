import os
import cv2
import numpy as np
import torch
from PIL import Image
from unet import UNet
from tqdm import tqdm
import matplotlib.pyplot as plt
from glob import glob


class Infer(object):
    def __init__(self):
        self.img_w = 256
        self.img_h = 256
        self.model_path = './checkpoints/CP_epoch20.pth'

        self.net = UNet(n_channels=3, n_classes=13)
        self.device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
        self.net.to(device=self.device)
        self.net.load_state_dict(torch.load(self.model_path, map_location=self.device))
        print("Model loaded !")

    def predict(self, img_path):
        img_ori = cv2.imread(img_path)
        h, w, _ = img_ori.shape
        img = cv2.resize(img_ori / 255.0, (self.img_w, self.img_h))

        img_input = torch.tensor(img).cuda()
        img_input = img_input.permute(2, 0, 1).unsqueeze(0)
        img_input = img_input.float()

        with torch.no_grad():
            mask = self.net(img_input)
            mask = mask[0].float().cpu().numpy()
            mask = np.uint8(np.argmax(mask, axis=0) )


        mask = cv2.cvtColor(mask, cv2.COLOR_GRAY2RGB)
        mask = cv2.resize(mask, (w, h))



        return img_ori, mask


if __name__ == '__main__':
    for index in range(1,9):
        img_dir = 'dataset/valid_images/'+str(index)+'/'
        mask_dir = 'dataset/valid_segment/'+str(index)+'/'
        save_dir = './predict_images/'+str(index)+'/'

        saver = Infer()
        for file in tqdm(glob(os.path.join(img_dir, '*'))):
            # mask_path = mask_dir + file.split("\\")[1].replace('images', 'valid')
            img, pred = saver.predict(file)
            mask = cv2.imread(file.replace('valid_images', 'valid_segment').replace('images', 'valid'))
            print(mask.min(), mask.max())
            mask = np.uint8(mask * 20)
            vis = np.hstack([img, pred, mask])
            vis = cv2.resize(vis, (256 * 3, 256))
            cv2.imshow('img', vis)
            cv2.waitKey(10)

            cv2.imwrite(os.path.join(save_dir, file.split('\\')[-1].replace('images', 'valid')), pred)




