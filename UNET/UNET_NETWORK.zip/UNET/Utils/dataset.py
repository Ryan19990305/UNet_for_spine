import os
from os.path import splitext
from os import listdir
import numpy as np
from glob import glob
import torch
from torch.utils.data import Dataset
import logging
import torchvision.transforms as tf
from PIL import Image
import cv2


class BasicDataset(Dataset):
    def __init__(self, imgs_dir, masks_dir, scale=1):
        self.imgs_dir = imgs_dir
        self.masks_dir = masks_dir
        self.scale = scale

        self.img_files = os.listdir(self.imgs_dir)
        logging.info(f'Creating dataset with {len(self.img_files)} examples')

        self.transforms = tf.Compose([
                    tf.ColorJitter(brightness=0.5, contrast=0.2)    #随机调整图片的饱和度和亮度   数值越大调整范围越大
                ])

    def __len__(self):
        return len(self.img_files)

    def data_aug(self, img):
        '''
            inputs type is Imageio    HWC
            outputs type is Imageio
        '''
        img = self.transforms(img)

        return img


    def __getitem__(self, i):
        mask_file = os.path.join(self.masks_dir, self.img_files[i].replace('training', 'manual'))
        img_file = os.path.join(self.imgs_dir, self.img_files[i])


        mask = cv2.imread(mask_file, 0)
        img  = cv2.imread(img_file)/255.0
        """ Removal of redundant features """
        # _h, _w = np.array(mask).shape[0], np.array(mask).shape[1]
        # for x in range(_h - 1):
        #     for y in range(_w - 1):
        #         if mask[x, y] == 0:
        #             img[x, y] == 0

        mask = cv2.resize(mask, (256,256))
        mask = np.expand_dims(mask, axis=0)


        img = cv2.resize(img, (256, 256))
        img = np.transpose(img, (2,0,1))

        #data augmentation
        # img = self.data_aug(img)


        return {'image': img, 'mask': mask}


