import os
import cv2
import numpy as np
from tqdm import tqdm

def imread(path):
    img = cv2.imread(path)
    img = cv2.resize(img, (320,240))
    img = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    img[img>0] = 1

    return img

def cmp_iou(img1, img2):
    intersection = np.sum(np.float32(img1+img2==2))
    union = np.sum(np.float32(img1+img2>0))

    # print(intersection, union)

    return intersection/union
def cmp_precision(lab, pred):
    correct = np.sum(np.float32(lab+pred==2))
    mask = np.sum(pred)+1e-12

    return correct/mask
def cmp_recall(lab, pred):
    correct = np.sum(np.float32(lab+pred==2))
    mask = np.sum(lab)+1e-12

    return correct/mask

def iou():
    lab_path = './data/test/masks'
    pred_path = './data/test/masks_pred'

    files = os.listdir(lab_path)

    iou_avr = 0
    precision_avr = 0
    recall_avr = 0
    cnt = 0

    for file in tqdm(files):
        lab = imread(os.path.join(lab_path, file))
        pred = imread(os.path.join(pred_path, file))
        iou = cmp_iou(lab, pred)
        precision = cmp_precision(lab, pred)
        recall = cmp_recall(lab, pred)

        iou_avr += iou
        precision_avr += precision
        recall_avr += recall
        cnt += 1

        # cv2.imshow('lab', lab*255)
        # cv2.imshow('pred', pred*255)
        # cv2.waitKey(10)
    iou_avr /= cnt
    precision_avr /= cnt
    recall_avr /= cnt
    print('iou_aver: ', iou_avr)
    print('precision_avr: ', precision_avr)
    print('recall_avr: ', recall_avr)

if __name__=='__main__':
    iou()